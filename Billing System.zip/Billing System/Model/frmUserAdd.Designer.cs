﻿namespace Billing_System.Model
{
    partial class frmUserAdd
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.InvlidN = new System.Windows.Forms.Label();
            this.uName = new Guna.UI2.WinForms.Guna2TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.uEmail = new Guna.UI2.WinForms.Guna2TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.uPhone = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2MessageDialog1 = new Guna.UI2.WinForms.Guna2MessageDialog();
            this.guna2MessageDialog2 = new Guna.UI2.WinForms.Guna2MessageDialog();
            this.guna2MessageDialog3 = new Guna.UI2.WinForms.Guna2MessageDialog();
            this.uRole = new Guna.UI2.WinForms.Guna2ComboBox();
            this.picuterBoxUser = new Guna.UI2.WinForms.Guna2PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.PicUpload = new Guna.UI2.WinForms.Guna2GradientButton();
            this.uPass = new Guna.UI2.WinForms.Guna2TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.checkBoxBTN = new Guna.UI2.WinForms.Guna2ToggleSwitch();
            ((System.ComponentModel.ISupportInitialize)(this.picuterBoxUser)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Size = new System.Drawing.Size(159, 33);
            this.label1.Text = "User Details";
            // 
            // InvlidN
            // 
            this.InvlidN.AutoSize = true;
            this.InvlidN.Font = new System.Drawing.Font("Segoe UI Emoji", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.InvlidN.Location = new System.Drawing.Point(51, 149);
            this.InvlidN.Name = "InvlidN";
            this.InvlidN.Size = new System.Drawing.Size(49, 20);
            this.InvlidN.TabIndex = 0;
            this.InvlidN.Text = "Name";
            // 
            // uName
            // 
            this.uName.BorderColor = System.Drawing.Color.DarkViolet;
            this.uName.BorderRadius = 9;
            this.uName.BorderThickness = 2;
            this.uName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.uName.DefaultText = "";
            this.uName.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.uName.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.uName.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.uName.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.uName.FillColor = System.Drawing.Color.Transparent;
            this.uName.FocusedState.BorderColor = System.Drawing.Color.Fuchsia;
            this.uName.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold);
            this.uName.ForeColor = System.Drawing.Color.DarkViolet;
            this.uName.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.uName.Location = new System.Drawing.Point(44, 173);
            this.uName.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.uName.Name = "uName";
            this.uName.PasswordChar = '\0';
            this.uName.PlaceholderForeColor = System.Drawing.Color.DimGray;
            this.uName.PlaceholderText = "first last";
            this.uName.SelectedText = "";
            this.uName.Size = new System.Drawing.Size(207, 52);
            this.uName.TabIndex = 1;
            this.uName.TabStop = false;
            this.uName.Tag = "v";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI Emoji", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(51, 389);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(71, 20);
            this.label3.TabIndex = 0;
            this.label3.Text = "Password";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI Emoji", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(291, 264);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(46, 20);
            this.label5.TabIndex = 0;
            this.label5.Text = "Email";
            // 
            // uEmail
            // 
            this.uEmail.BorderColor = System.Drawing.Color.DarkViolet;
            this.uEmail.BorderRadius = 9;
            this.uEmail.BorderThickness = 2;
            this.uEmail.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.uEmail.DefaultText = "";
            this.uEmail.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.uEmail.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.uEmail.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.uEmail.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.uEmail.FillColor = System.Drawing.Color.Transparent;
            this.uEmail.FocusedState.BorderColor = System.Drawing.Color.Fuchsia;
            this.uEmail.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold);
            this.uEmail.ForeColor = System.Drawing.Color.DarkViolet;
            this.uEmail.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.uEmail.Location = new System.Drawing.Point(284, 288);
            this.uEmail.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.uEmail.Name = "uEmail";
            this.uEmail.PasswordChar = '\0';
            this.uEmail.PlaceholderForeColor = System.Drawing.Color.DimGray;
            this.uEmail.PlaceholderText = "user@gmail.com";
            this.uEmail.SelectedText = "";
            this.uEmail.Size = new System.Drawing.Size(207, 52);
            this.uEmail.TabIndex = 5;
            this.uEmail.TabStop = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI Emoji", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(51, 264);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(50, 20);
            this.label6.TabIndex = 0;
            this.label6.Text = "Phone";
            // 
            // uPhone
            // 
            this.uPhone.BorderColor = System.Drawing.Color.DarkViolet;
            this.uPhone.BorderRadius = 9;
            this.uPhone.BorderThickness = 2;
            this.uPhone.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.uPhone.DefaultText = "";
            this.uPhone.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.uPhone.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.uPhone.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.uPhone.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.uPhone.FillColor = System.Drawing.Color.Transparent;
            this.uPhone.FocusedState.BorderColor = System.Drawing.Color.Fuchsia;
            this.uPhone.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold);
            this.uPhone.ForeColor = System.Drawing.Color.DarkViolet;
            this.uPhone.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.uPhone.Location = new System.Drawing.Point(44, 288);
            this.uPhone.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.uPhone.Name = "uPhone";
            this.uPhone.PasswordChar = '\0';
            this.uPhone.PlaceholderForeColor = System.Drawing.Color.DimGray;
            this.uPhone.PlaceholderText = "0767776665";
            this.uPhone.SelectedText = "";
            this.uPhone.Size = new System.Drawing.Size(207, 52);
            this.uPhone.TabIndex = 4;
            this.uPhone.TabStop = false;
            // 
            // guna2MessageDialog1
            // 
            this.guna2MessageDialog1.Buttons = Guna.UI2.WinForms.MessageDialogButtons.OK;
            this.guna2MessageDialog1.Caption = "Billing System";
            this.guna2MessageDialog1.Icon = Guna.UI2.WinForms.MessageDialogIcon.Information;
            this.guna2MessageDialog1.Parent = this;
            this.guna2MessageDialog1.Style = Guna.UI2.WinForms.MessageDialogStyle.Dark;
            this.guna2MessageDialog1.Text = "User has been Successfully Added.       ";
            // 
            // guna2MessageDialog2
            // 
            this.guna2MessageDialog2.Buttons = Guna.UI2.WinForms.MessageDialogButtons.YesNo;
            this.guna2MessageDialog2.Caption = "Billing System";
            this.guna2MessageDialog2.Icon = Guna.UI2.WinForms.MessageDialogIcon.Question;
            this.guna2MessageDialog2.Parent = this;
            this.guna2MessageDialog2.Style = Guna.UI2.WinForms.MessageDialogStyle.Dark;
            this.guna2MessageDialog2.Text = "Are you sure You want to Delete ?.       ";
            // 
            // guna2MessageDialog3
            // 
            this.guna2MessageDialog3.Buttons = Guna.UI2.WinForms.MessageDialogButtons.OK;
            this.guna2MessageDialog3.Caption = "Billing System";
            this.guna2MessageDialog3.Icon = Guna.UI2.WinForms.MessageDialogIcon.Information;
            this.guna2MessageDialog3.Parent = this;
            this.guna2MessageDialog3.Style = Guna.UI2.WinForms.MessageDialogStyle.Dark;
            this.guna2MessageDialog3.Text = "User has been Successfully Update.        ";
            // 
            // uRole
            // 
            this.uRole.BackColor = System.Drawing.Color.Transparent;
            this.uRole.BorderColor = System.Drawing.Color.DarkViolet;
            this.uRole.BorderRadius = 9;
            this.uRole.BorderThickness = 2;
            this.uRole.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.uRole.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.uRole.FillColor = System.Drawing.Color.Black;
            this.uRole.FocusedColor = System.Drawing.Color.Fuchsia;
            this.uRole.FocusedState.BorderColor = System.Drawing.Color.Fuchsia;
            this.uRole.Font = new System.Drawing.Font("Segoe UI Emoji", 9F, System.Drawing.FontStyle.Bold);
            this.uRole.ForeColor = System.Drawing.Color.DarkViolet;
            this.uRole.ItemHeight = 39;
            this.uRole.Location = new System.Drawing.Point(281, 173);
            this.uRole.Name = "uRole";
            this.uRole.Size = new System.Drawing.Size(207, 45);
            this.uRole.TabIndex = 12;
            // 
            // picuterBoxUser
            // 
            this.picuterBoxUser.BackColor = System.Drawing.Color.Transparent;
            this.picuterBoxUser.FillColor = System.Drawing.Color.Transparent;
            this.picuterBoxUser.Image = global::Billing_System.Properties.Resources.logomain;
            this.picuterBoxUser.ImageRotate = 0F;
            this.picuterBoxUser.Location = new System.Drawing.Point(527, 134);
            this.picuterBoxUser.Name = "picuterBoxUser";
            this.picuterBoxUser.Size = new System.Drawing.Size(285, 317);
            this.picuterBoxUser.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picuterBoxUser.TabIndex = 10;
            this.picuterBoxUser.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI Emoji", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(288, 149);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(39, 20);
            this.label2.TabIndex = 9;
            this.label2.Text = "Role";
            // 
            // PicUpload
            // 
            this.PicUpload.Animated = true;
            this.PicUpload.BackColor = System.Drawing.Color.Transparent;
            this.PicUpload.BorderColor = System.Drawing.Color.MediumOrchid;
            this.PicUpload.BorderRadius = 3;
            this.PicUpload.BorderThickness = 3;
            this.PicUpload.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.PicUpload.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.PicUpload.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.PicUpload.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.PicUpload.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.PicUpload.FillColor = System.Drawing.Color.DarkViolet;
            this.PicUpload.FillColor2 = System.Drawing.Color.MediumOrchid;
            this.PicUpload.Font = new System.Drawing.Font("Segoe UI Semibold", 10.2F, System.Drawing.FontStyle.Bold);
            this.PicUpload.ForeColor = System.Drawing.Color.White;
            this.PicUpload.HoverState.BorderColor = System.Drawing.Color.Fuchsia;
            this.PicUpload.Image = global::Billing_System.Properties.Resources.folder;
            this.PicUpload.ImageOffset = new System.Drawing.Point(-3, 2);
            this.PicUpload.ImageSize = new System.Drawing.Size(25, 25);
            this.PicUpload.Location = new System.Drawing.Point(527, 443);
            this.PicUpload.Name = "PicUpload";
            this.PicUpload.Size = new System.Drawing.Size(285, 55);
            this.PicUpload.TabIndex = 13;
            this.PicUpload.Text = "BROWSE";
            this.PicUpload.UseTransparentBackground = true;
            this.PicUpload.Click += new System.EventHandler(this.PicUpload_Click);
            // 
            // uPass
            // 
            this.uPass.BorderColor = System.Drawing.Color.DarkViolet;
            this.uPass.BorderRadius = 9;
            this.uPass.BorderThickness = 2;
            this.uPass.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.uPass.DefaultText = "";
            this.uPass.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.uPass.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.uPass.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.uPass.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.uPass.FillColor = System.Drawing.Color.Transparent;
            this.uPass.FocusedState.BorderColor = System.Drawing.Color.Fuchsia;
            this.uPass.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold);
            this.uPass.ForeColor = System.Drawing.Color.DarkViolet;
            this.uPass.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.uPass.Location = new System.Drawing.Point(44, 413);
            this.uPass.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.uPass.Name = "uPass";
            this.uPass.PasswordChar = '\0';
            this.uPass.PlaceholderForeColor = System.Drawing.Color.DimGray;
            this.uPass.PlaceholderText = "user12#@";
            this.uPass.SelectedText = "";
            this.uPass.Size = new System.Drawing.Size(207, 52);
            this.uPass.TabIndex = 14;
            this.uPass.TabStop = false;
            this.uPass.Tag = "v";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI Emoji", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(335, 431);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(99, 17);
            this.label4.TabIndex = 17;
            this.label4.Text = "Show Password";
            // 
            // checkBoxBTN
            // 
            this.checkBoxBTN.CheckedState.BorderColor = System.Drawing.Color.DarkViolet;
            this.checkBoxBTN.CheckedState.BorderThickness = 2;
            this.checkBoxBTN.CheckedState.FillColor = System.Drawing.Color.DarkViolet;
            this.checkBoxBTN.CheckedState.InnerBorderColor = System.Drawing.Color.White;
            this.checkBoxBTN.CheckedState.InnerColor = System.Drawing.Color.White;
            this.checkBoxBTN.Location = new System.Drawing.Point(295, 428);
            this.checkBoxBTN.Name = "checkBoxBTN";
            this.checkBoxBTN.Size = new System.Drawing.Size(38, 24);
            this.checkBoxBTN.TabIndex = 16;
            this.checkBoxBTN.TabStop = false;
            this.checkBoxBTN.UncheckedState.BorderColor = System.Drawing.Color.DarkViolet;
            this.checkBoxBTN.UncheckedState.BorderThickness = 2;
            this.checkBoxBTN.UncheckedState.FillColor = System.Drawing.Color.Transparent;
            this.checkBoxBTN.UncheckedState.InnerBorderColor = System.Drawing.Color.White;
            this.checkBoxBTN.UncheckedState.InnerColor = System.Drawing.Color.White;
            this.checkBoxBTN.CheckedChanged += new System.EventHandler(this.checkBoxBTN_CheckedChanged);
            // 
            // frmUserAdd
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 22F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(895, 623);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.checkBoxBTN);
            this.Controls.Add(this.uPass);
            this.Controls.Add(this.PicUpload);
            this.Controls.Add(this.uRole);
            this.Controls.Add(this.picuterBoxUser);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.uEmail);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.uPhone);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.InvlidN);
            this.Controls.Add(this.uName);
            this.Name = "frmUserAdd";
            this.Text = "frmUserAdd";
            this.Load += new System.EventHandler(this.frmUserAdd_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picuterBoxUser)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label InvlidN;
        private Guna.UI2.WinForms.Guna2TextBox uName;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private Guna.UI2.WinForms.Guna2TextBox uEmail;
        private System.Windows.Forms.Label label6;
        private Guna.UI2.WinForms.Guna2TextBox uPhone;
        public Guna.UI2.WinForms.Guna2MessageDialog guna2MessageDialog1;
        public Guna.UI2.WinForms.Guna2MessageDialog guna2MessageDialog2;
        public Guna.UI2.WinForms.Guna2MessageDialog guna2MessageDialog3;
        private Guna.UI2.WinForms.Guna2ComboBox uRole;
        private Guna.UI2.WinForms.Guna2PictureBox picuterBoxUser;
        private System.Windows.Forms.Label label2;
        public Guna.UI2.WinForms.Guna2GradientButton PicUpload;
        private Guna.UI2.WinForms.Guna2TextBox uPass;
        private System.Windows.Forms.Label label4;
        private Guna.UI2.WinForms.Guna2ToggleSwitch checkBoxBTN;
    }
}