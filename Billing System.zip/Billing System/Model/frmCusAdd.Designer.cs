﻿namespace Billing_System.Model
{
    partial class frmCusAdd
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        public Guna.UI2.WinForms.Guna2MessageDialog guna2MessageDialog1;
        public Guna.UI2.WinForms.Guna2MessageDialog guna2MessageDialog2;
        public Guna.UI2.WinForms.Guna2MessageDialog guna2MessageDialog3;

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>

        private void InitializeComponent()
        {
            this.label3 = new System.Windows.Forms.Label();
            this.cPhone = new Guna.UI2.WinForms.Guna2TextBox();
            this.InvlidN = new System.Windows.Forms.Label();
            this.cName = new Guna.UI2.WinForms.Guna2TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.cEmail = new Guna.UI2.WinForms.Guna2TextBox();
            this.cAddress = new Guna.UI2.WinForms.Guna2TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.guna2MessageDialog1 = new Guna.UI2.WinForms.Guna2MessageDialog();
            this.guna2MessageDialog2 = new Guna.UI2.WinForms.Guna2MessageDialog();
            this.guna2MessageDialog3 = new Guna.UI2.WinForms.Guna2MessageDialog();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Size = new System.Drawing.Size(220, 33);
            this.label1.Text = "Customer Details";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI Emoji", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(320, 125);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(50, 20);
            this.label3.TabIndex = 11;
            this.label3.Text = "Phone";
            // 
            // cPhone
            // 
            this.cPhone.BorderColor = System.Drawing.Color.DarkViolet;
            this.cPhone.BorderRadius = 9;
            this.cPhone.BorderThickness = 2;
            this.cPhone.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.cPhone.DefaultText = "";
            this.cPhone.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.cPhone.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.cPhone.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.cPhone.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.cPhone.FillColor = System.Drawing.Color.Transparent;
            this.cPhone.FocusedState.BorderColor = System.Drawing.Color.Fuchsia;
            this.cPhone.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold);
            this.cPhone.ForeColor = System.Drawing.Color.DarkViolet;
            this.cPhone.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cPhone.Location = new System.Drawing.Point(324, 149);
            this.cPhone.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.cPhone.Name = "cPhone";
            this.cPhone.PasswordChar = '\0';
            this.cPhone.PlaceholderForeColor = System.Drawing.Color.DimGray;
            this.cPhone.PlaceholderText = "Phone No";
            this.cPhone.SelectedText = "";
            this.cPhone.Size = new System.Drawing.Size(299, 59);
            this.cPhone.TabIndex = 12;
            this.cPhone.TabStop = false;
            this.cPhone.Tag = "v";
            // 
            // InvlidN
            // 
            this.InvlidN.AutoSize = true;
            this.InvlidN.Font = new System.Drawing.Font("Segoe UI Emoji", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.InvlidN.Location = new System.Drawing.Point(15, 125);
            this.InvlidN.Name = "InvlidN";
            this.InvlidN.Size = new System.Drawing.Size(49, 20);
            this.InvlidN.TabIndex = 9;
            this.InvlidN.Text = "Name";
            // 
            // cName
            // 
            this.cName.BorderColor = System.Drawing.Color.DarkViolet;
            this.cName.BorderRadius = 9;
            this.cName.BorderThickness = 2;
            this.cName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.cName.DefaultText = "";
            this.cName.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.cName.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.cName.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.cName.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.cName.FillColor = System.Drawing.Color.Transparent;
            this.cName.FocusedState.BorderColor = System.Drawing.Color.Fuchsia;
            this.cName.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold);
            this.cName.ForeColor = System.Drawing.Color.DarkViolet;
            this.cName.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cName.Location = new System.Drawing.Point(19, 149);
            this.cName.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.cName.Name = "cName";
            this.cName.PasswordChar = '\0';
            this.cName.PlaceholderForeColor = System.Drawing.Color.DimGray;
            this.cName.PlaceholderText = "Customer Name";
            this.cName.SelectedText = "";
            this.cName.Size = new System.Drawing.Size(299, 59);
            this.cName.TabIndex = 10;
            this.cName.TabStop = false;
            this.cName.Tag = "v";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI Emoji", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(634, 125);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(46, 20);
            this.label2.TabIndex = 13;
            this.label2.Text = "Email";
            // 
            // cEmail
            // 
            this.cEmail.BorderColor = System.Drawing.Color.DarkViolet;
            this.cEmail.BorderRadius = 9;
            this.cEmail.BorderThickness = 2;
            this.cEmail.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.cEmail.DefaultText = "";
            this.cEmail.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.cEmail.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.cEmail.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.cEmail.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.cEmail.FillColor = System.Drawing.Color.Transparent;
            this.cEmail.FocusedState.BorderColor = System.Drawing.Color.Fuchsia;
            this.cEmail.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold);
            this.cEmail.ForeColor = System.Drawing.Color.DarkViolet;
            this.cEmail.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cEmail.Location = new System.Drawing.Point(627, 149);
            this.cEmail.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.cEmail.Name = "cEmail";
            this.cEmail.PasswordChar = '\0';
            this.cEmail.PlaceholderForeColor = System.Drawing.Color.DimGray;
            this.cEmail.PlaceholderText = "Email Address";
            this.cEmail.SelectedText = "";
            this.cEmail.Size = new System.Drawing.Size(299, 59);
            this.cEmail.TabIndex = 14;
            this.cEmail.TabStop = false;
            this.cEmail.Tag = "v";
            // 
            // cAddress
            // 
            this.cAddress.BorderColor = System.Drawing.Color.DarkViolet;
            this.cAddress.BorderRadius = 9;
            this.cAddress.BorderThickness = 2;
            this.cAddress.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.cAddress.DefaultText = "";
            this.cAddress.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.cAddress.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.cAddress.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.cAddress.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.cAddress.FillColor = System.Drawing.Color.Transparent;
            this.cAddress.FocusedState.BorderColor = System.Drawing.Color.Fuchsia;
            this.cAddress.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold);
            this.cAddress.ForeColor = System.Drawing.Color.DarkViolet;
            this.cAddress.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cAddress.Location = new System.Drawing.Point(19, 249);
            this.cAddress.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.cAddress.Name = "cAddress";
            this.cAddress.PasswordChar = '\0';
            this.cAddress.PlaceholderForeColor = System.Drawing.Color.DimGray;
            this.cAddress.PlaceholderText = "Address";
            this.cAddress.SelectedText = "";
            this.cAddress.Size = new System.Drawing.Size(907, 59);
            this.cAddress.TabIndex = 15;
            this.cAddress.TabStop = false;
            this.cAddress.Tag = "v";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI Emoji", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(15, 225);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(62, 20);
            this.label4.TabIndex = 16;
            this.label4.Text = "Address";
            // 
            // guna2MessageDialog1
            // 
            this.guna2MessageDialog1.Buttons = Guna.UI2.WinForms.MessageDialogButtons.OK;
            this.guna2MessageDialog1.Caption = null;
            this.guna2MessageDialog1.Icon = Guna.UI2.WinForms.MessageDialogIcon.None;
            this.guna2MessageDialog1.Parent = null;
            this.guna2MessageDialog1.Style = Guna.UI2.WinForms.MessageDialogStyle.Default;
            this.guna2MessageDialog1.Text = null;
            // 
            // guna2MessageDialog2
            // 
            this.guna2MessageDialog2.Buttons = Guna.UI2.WinForms.MessageDialogButtons.OK;
            this.guna2MessageDialog2.Caption = null;
            this.guna2MessageDialog2.Icon = Guna.UI2.WinForms.MessageDialogIcon.None;
            this.guna2MessageDialog2.Parent = null;
            this.guna2MessageDialog2.Style = Guna.UI2.WinForms.MessageDialogStyle.Default;
            this.guna2MessageDialog2.Text = null;
            // 
            // guna2MessageDialog3
            // 
            this.guna2MessageDialog3.Buttons = Guna.UI2.WinForms.MessageDialogButtons.OK;
            this.guna2MessageDialog3.Caption = null;
            this.guna2MessageDialog3.Icon = Guna.UI2.WinForms.MessageDialogIcon.None;
            this.guna2MessageDialog3.Parent = null;
            this.guna2MessageDialog3.Style = Guna.UI2.WinForms.MessageDialogStyle.Default;
            this.guna2MessageDialog3.Text = null;
            // 
            // frmCusAdd
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 22F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(944, 450);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.cAddress);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.cEmail);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.cPhone);
            this.Controls.Add(this.InvlidN);
            this.Controls.Add(this.cName);
            this.Name = "frmCusAdd";
            this.Text = "frmCusAdd";
            this.Load += new System.EventHandler(this.frmCusAdd_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label3;
        private Guna.UI2.WinForms.Guna2TextBox cPhone;
        private System.Windows.Forms.Label InvlidN;
        private Guna.UI2.WinForms.Guna2TextBox cName;
        private System.Windows.Forms.Label label2;
        private Guna.UI2.WinForms.Guna2TextBox cEmail;
        private Guna.UI2.WinForms.Guna2TextBox cAddress;
        private System.Windows.Forms.Label label4;
    }
}